my(@a,%hash,@b);
open F1,$ARGV[0];
while (<F1>){
	chomp;
	next if(/^CHROM/);
	@a=split/\t/,$_;
	$window1="$a[0]\t$a[1]\t$a[2]";
	$hash{$window1}{overlap_window}="$_";
	}
open F2,$ARGV[1];
while (<F2>) {
	next if(/^CHROM/);
	chomp;
	@b=split/\t/,$_;
	$window2="$b[0]\t$b[1]\t$b[2]";
	print"$hash{$window2}{overlap_window}\n"
	}
close F1;
close F2;
