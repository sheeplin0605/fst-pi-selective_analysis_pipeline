#### This pipeline of fst-pi is suitable for selection and analysis of two groups/populations ####
#### If you encounter any problems, you can contact sheeplin0605@163.com ####

#get *.windowed.pi and *.windowed.weir.fst by vcftools; 19north and 32south are individuls in one population that you care about; the window step size you can adjust by yourself,here we used "-window-pi 50000 --window-pi-step 25000";  
vcftools --vcf max-missing0.8minDP4maf0.05-1470027.single.snp.vcf --keep 19north --window-pi 50000 --window-pi-step 25000 --out 19north-1M
vcftools --vcf max-missing0.8minDP4maf0.05-1470027.single.snp.vcf --keep 32south --window-pi 50000 --window-pi-step 25000 --out 32south-1M
vcftools --vcf max-missing0.8minDP4maf0.05-1470027.single.snp.vcf --fst-window-size 50000  --fst-window-step 25000 --weir-fst-pop 19north --weir-fst-pop 32south --out 19orth-32south-1M
#merge *fst and *pi by new_merge_Fst_Pi-A_Pi-B.pl; 
perl new_merge_Fst_Pi-A_Pi-B.pl 19north-32south-1M.windowed.weir.fst 19north-1M.windowed.pi 32south-1M.windowed.pi >north-south.merge
#reorder Fst and pi by merge2ready.r
Rscript merge2ready.r
#count how many windows in *Fst_order.txt and *pi_order.txt, according to this you can choose the top5%Fst_and_top5%pi windows for the next analysis;
wc -l north-south_weight_Fst_order.txt
wc -l north-south_pi_order.txt
#if there are 50000 windows in north-south_weight_Fst_order.txt, this step you can type "head -n 5000 north-south_weight_Fst_order.txt >TOP5_north-south_weight_Fst_order.txt";
head -n top5 north-south_weight_Fst_order.txt >TOP5_north-south_weight_Fst_order.txt
head -n top5  north-south_pi_order.txt >TOP5_north-south_pi_order.txt
tail -n top5  north-south_pi_order.txt >Tail5_north-south_pi_order.txt #the selective widows of *pi_order.txt are the pi-values that usually are smaller, so here we used "tail -n top5";
#get selective windows by overlapping the top5%Fst and top5%pi in overlap_top5Fst_and_top5pi.pl; 
perl overlap_top5Fst_and_top5pi.pl TOP5_north-south_weight_Fst_order.txt TOP5_north-south_pi_order.txt |perl -e 'while(<>){if(/./){print}}' |sort -k1.3 -n -k2n >north.TOP5-fst-pi.selection.sort.txt
perl overlap_top5Fst_and_top5pi.pl TOP5_north-south_weight_Fst_order.txt Tail5_north-south_pi_order.txt |perl -e 'while(<>){if(/./){print}}' |sort -k1.3 -n -k2n >south.TOP5-fst-pi.selection.sort.txt
#get *selection.geneID.txt with your annotation file(.gff) by bedtools;
bedtools intersect -a SL.final.gff -b north.TOP5-fst-pi.selection.sort.txt  -wa -wb |grep gene |perl -e 'while(<>){if(/ID=(SL_LG.*)\tLG/){print"$1\n";}}' |uniq >north.selection.geneID.txt
bedtools intersect -a SL.final.gff -b south.TOP5-fst-pi.selection.sort.txt  -wa -wb |grep gene |perl -e 'while(<>){if(/ID=(SL_LG.*)\tLG/){print"$1\n";}}' |uniq >south.selection.geneID.txt
#get selective gene lists by Annotation_Summary.xls;
for i in `cat north.selection.geneID.txt`
do
echo "grep '$i' Annotation_Summary.xls |head -n 1 >>north.selection.Annotation"
done > north.selection.Annotation.list
for i in `cat south.selection.geneID.txt`
do
echo "grep '$i' Annotation_Summary.xls |head -n 1 >>south.selection.Annotation"
done > south.selection.Annotation.list
ParaFly -c north.selection.Annotation.list -CPU 50
ParaFly -c south.selection.Annotation.list -CPU 50
perl -e 'while(<>){if(/SL.*GN=(.*)\s+PE/){print"$1\n"}}' north.selection.Annotation |sort |uniq >north.selection.genelist.txt
perl -e 'while(<>){if(/SL.*GN=(.*)\s+PE/){print"$1\n"}}' south.selection.Annotation |sort |uniq >south.selection.genelist.txt
