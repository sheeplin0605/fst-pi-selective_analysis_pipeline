mergefile <- "north-south.merge"
mydata<-read.table(mergefile,sep="\t",header=T,stringsAsFactors=F)
mynewdata <- na.omit(mydata)
names(mynewdata) <- c("CHROM","BIN_START","BIN_END","WEIGHTED_FST","MEAN_FST","north_pi","south_pi")
attach(mynewdata)
weight_Fst <- (WEIGHTED_FST-mean(WEIGHTED_FST))/sd(WEIGHTED_FST)
pi <- log2(north_pi)-log2(south_pi)
file1 <- cbind(CHROM,BIN_START,BIN_END,weight_Fst,pi)
weight <- file1[order(weight_Fst,decreasing= T),]
Pi <- file1[order(pi),]
write.table(file1,file="weight_Fst-Pi-north-south.txt",row.names=F,quote=F,sep="\t")
write.table(Pi,file="north-south_pi_order.txt",row.names=F,quote=F,sep="\t")
write.table(weight,file="north-south_weight_Fst_order.txt",row.names=F,quote=F,sep="\t")
