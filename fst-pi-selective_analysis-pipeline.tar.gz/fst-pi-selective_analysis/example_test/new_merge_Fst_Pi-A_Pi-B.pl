#!/usr/bin/perl 
#use strict;
#use utf8;
my $Usage =<<usage;
usage:
    $0 Fst.file Pi-A.file Pi-B.file > merge.file
usage
if (@ARGV == 0){die $Usage}
my (@line1,$Fst_region,@i,%hash1,@line2,$Pi_region1,%hash2,@line3,$Pi_region2,%hash3);
open IN1,$ARGV[0] or die $!;
<IN1>;
while (<IN1>){
	chomp;
        @line1 = split/\t/,$_;
	$Fst_region = "$line1[0]\t$line1[1]\t$line1[2]";
	push @i,$Fst_region;
	$hash1{$Fst_region} = "$line1[4]\t$line1[5]";
	}

open IN2,$ARGV[1] or die $!;
<IN2>;
while (<IN2>){
	chomp;
	@line2 = split/\t/,$_;
        $Pi_region1 = "$line2[0]\t$line2[1]\t$line2[2]";
	$hash2{$Pi_region1}="$line2[4]";
	}

open IN3,$ARGV[2] or die $!;
<IN3>;
while (<IN3>){
	chomp;
        @line3 = split/\t/,$_;
	$Pi_region2 =  "$line3[0]\t$line3[1]\t$line3[2]";
	$hash3{$Pi_region2}="$line3[4]";
	}
print "CHROM\tBIN_START\tBIN_END\tWEIGHTED_FST\tMEAN_FST\tPI-A\tPI-B\n";
foreach (@i){
	print "$_\t$hash1{$_}\t$hash2{$_}\t$hash3{$_}\n";
	}
close IN1;
close IN2;
close IN3;
